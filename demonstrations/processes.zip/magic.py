import ctypes
import ctypes.wintypes
import struct
ntdll = ctypes.windll.ntdll

SystemProcessInformation = ctypes.wintypes.DWORD(5)

# This example uses NtQuerySystemInformation with SystemProcessInformation class to retrieve process names
# running on a system.
# Reference: https://docs.microsoft.com/en-us/windows/win32/api/winternl/nf-winternl-ntquerysysteminformation

# Check how much space NtQuerySystemInformation needs.
expected = ctypes.wintypes.ULONG(0)
status = ntdll.NtQuerySystemInformation(SystemProcessInformation, None, ctypes.wintypes.ULONG(0), ctypes.byref(expected))

if 0 == expected.value:
    print("ERROR: NTQSI returned unexpected ReturnLength 0; return code=%x\n" % status)
else:
    # Allocate two times what the function needs, in case new processes are created in between these two calls.
    size = ctypes.wintypes.ULONG(expected.value*2)

    # Allocate buffer s of new `size`, reset `expected` to 0.
    s = ctypes.create_string_buffer(size.value)
    expected = ctypes.wintypes.ULONG(0)

    # Call NtQuerySystemInformation again.
    status = ntdll.NtQuerySystemInformation(SystemProcessInformation, ctypes.cast(s, ctypes.c_char_p), size, ctypes.byref(expected))
    if 0 != status:
        print("ERROR: NTQSI 2nd call returned unexpected code=%x\n" % status)
    else:
        # Sizes of fields in SYSTEM_PROCESS_INFORMATION structure
        # We only care about the name of the process (ImageName field, which is a UNICODE_STRING structure)
        # typedef struct _SYSTEM_PROCESS_INFORMATION {
        #    ULONG NextEntryOffset;
        #    ULONG NumberOfThreads;
        #    BYTE Reserved1[48];
        #    UNICODE_STRING ImageName;
        #    ...
        # }
        #

        next_entry = 4
        thread_count = 4
        reserved1 = 4*6
        times = 8*3
        name_length = 2
        name_offset = 8  # 8 here for x64 instead of 4 since UNICODE_STRING structure fields are word-aligned
        name_ptr_size = 8
        name_location = next_entry+thread_count+reserved1+times

        current = 0
        while True:
            next = struct.unpack("<I", s[current:current+4])[0]
            name_size = struct.unpack("<H", s[current+name_location:current+name_location+name_length])[0]
            if name_size > 0:
                # Buffer field in UNICODE_STRING points somewhere in s.... Let's find it.
                name_address = struct.unpack("<Q", s[current+name_location+name_offset:current+name_location+name_offset+name_ptr_size])[0]
                name_string_offset = name_address - ctypes.addressof(s)
                name = s[name_string_offset:name_string_offset+name_size]
                print(name.decode("utf-16"))
            else:
                # This process has no name, and there should be only one (the first one).
                print("System Idle Process")
            if next == 0:
                # No more entries.
                break
            current += next