import ctypes
ctypes.windll.user32.MessageBoxA(0, b'Hello, world!', b'WOOT 2021', 0)